import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class ConversorTemperatura {

	private JFrame frmAluraOne;
	private JSlider sldValor;
	private JLabel lblValor;
	double  valor = 1;
	private JLabel lblNewLabel_1;
	private JLabel lblResultado;
	private JComboBox cboDE;
	private JComboBox cboA;
	String de="Cº",a="Cº";
	double temp=0.0;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConversorTemperatura window = new ConversorTemperatura();
					window.frmAluraOne.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ConversorTemperatura() {
		initialize();
	}
	
	public double redondear(double temp) {
		return Math.round(temp*100.0)/100.0;
	}
	
	public void convertirTemperatura(){
		switch(de){
		case "Cº":
			if(a.equals("Fº")) {
				temp=((9*valor)/5)+32;
			}else if(a.equals("Kº")){
				temp=valor + 273.15;
			}else{
				temp=valor;
			}
			break;
		case "Fº":
            if(a.equals("Cº")) {
            	temp=(5*(valor - 32)) /9;
			}else if(a.equals("Kº")){
				temp=((5*(valor-32))/9)+273.15;
			}else{
				temp=valor;
			}
			break;
		case "Kº":
            if(a.equals("Fº")) {
            	temp=((9*(valor-273.15))/5)+32;
			}else if(a.equals("Cº")){
				temp=valor-273.15;
			}else{
				temp=valor;
			}
			
            break;
		}
		lblResultado.setText(valor+""+de+" -> "+ redondear(temp)+"" +a);
	}

	private void initialize() {
		frmAluraOne = new JFrame();
		frmAluraOne.getContentPane().setBackground(new Color(255, 128, 128));
		frmAluraOne.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\usuario\\OneDrive\\Imágenes\\Saved Pictures\\bandera cr.png"));
		frmAluraOne.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 28));
		frmAluraOne.setBounds(100, 100, 450, 300);
		frmAluraOne.setTitle("ALURA ONE 5 CONVERSOR DE TEMPERATURA");
		frmAluraOne.setLocationRelativeTo(null);
		frmAluraOne.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAluraOne.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Valor");
		lblNewLabel.setBounds(21, 27, 46, 14);
		frmAluraOne.getContentPane().add(lblNewLabel);
		

		lblValor = new JLabel("1");
		lblValor.setHorizontalAlignment(SwingConstants.CENTER);
		lblValor.setFont(new Font("Tahoma",Font.BOLD,20));
		lblValor.setBorder(new LineBorder(new Color(0,0,0)));
		lblValor.setBounds(364, 41, 68, 59);
		frmAluraOne.getContentPane().add(lblValor);
		
		lblResultado = new JLabel("1");
		lblResultado.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblResultado.setHorizontalAlignment(SwingConstants.CENTER);
		lblResultado.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblResultado.setBounds(43, 198, 326, 60);
		frmAluraOne.getContentPane().add(lblResultado);
		
		
		sldValor = new JSlider();
		sldValor.setBackground(new Color(128, 128, 128));
		sldValor.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				valor=sldValor.getValue();
				lblValor.setText(""+valor);
			}
		});
		sldValor.setPaintTicks(true);
		sldValor.setPaintLabels(true);
		sldValor.setValue(1);
		sldValor.setMinimum(1);
		sldValor.setBounds(10, 52, 344, 43);
		frmAluraOne.getContentPane().add(sldValor);
		
		lblNewLabel_1 = new JLabel("DE :");
		lblNewLabel_1.setBounds(21, 133, 46, 14);
		frmAluraOne.getContentPane().add(lblNewLabel_1);
		
		cboDE = new JComboBox();
		cboDE.setBackground(new Color(128, 128, 128));
		cboDE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				de=cboDE.getSelectedItem().toString();
				convertirTemperatura();
			}
		});
		cboDE.setModel(new DefaultComboBoxModel(new String[] {"Cº","Fº","Kº"}));
		cboDE.setBounds(54, 129, 128, 35);
		frmAluraOne.getContentPane().add(cboDE);
		
		cboA = new JComboBox();
		cboA.setBackground(new Color(128, 128, 128));
		cboA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a=cboA.getSelectedItem().toString();
				convertirTemperatura();
			}
		});
		cboA.setModel(new DefaultComboBoxModel(new String[] {"Cº","Fº","Kº"}));
		cboA.setBounds(287, 129, 145, 35);
		frmAluraOne.getContentPane().add(cboA);
		
		JLabel lblNewLabel_2 = new JLabel("A :");
		lblNewLabel_2.setBounds(220, 129, 57, 35);
		frmAluraOne.getContentPane().add(lblNewLabel_2);
		
	}
}
