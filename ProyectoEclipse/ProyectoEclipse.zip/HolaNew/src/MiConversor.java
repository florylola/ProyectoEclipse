import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.ImageIcon;

public class MiConversor {

	private JFrame frmAluraOne;
	private JTextField txt;
	private JComboBox cmb;
	private JButton btn;
	private JLabel lbl;
	
	public enum Moneda{
		colones_dolar,
		colones_euro,
		colones_libra,
		dolar_colones,
		euro_colones,
		libra_colones,
	}
	
	public double dolar = 539.66;
	public double euro = 591.42;
	public double libra = 691.79;
	
	public double valorInput = 0.00;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MiConversor window = new MiConversor();
					window.frmAluraOne.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MiConversor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAluraOne = new JFrame();
		frmAluraOne.getContentPane().setBackground(new Color(255, 128, 128));
		frmAluraOne.setTitle("ALURA ONE 5 CONVERSOR DE MONEDA");
		frmAluraOne.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\usuario\\OneDrive\\Imágenes\\Saved Pictures\\bandera cr.png"));
		frmAluraOne.setBounds(100, 100, 450, 300);
		frmAluraOne.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAluraOne.getContentPane().setLayout(null);
		
		txt = new JTextField();
		txt.setBounds(10, 11, 123, 20);
		frmAluraOne.getContentPane().add(txt);
		txt.setColumns(10);
		
		cmb = new JComboBox<Moneda>();
		cmb.setModel(new DefaultComboBoxModel<>(Moneda.values()));
		cmb.setBounds(10, 59, 123, 22);
		frmAluraOne.getContentPane().add(cmb);
		
		//evento boton//
		btn = new JButton("Convertir");
		btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Convertir();
			}
		});  
		btn.setBounds(161, 59, 89, 23);
		frmAluraOne.getContentPane().add(btn);
		
		lbl = new JLabel("00.00");
		lbl.setBounds(161, 11, 89, 20);
		frmAluraOne.getContentPane().add(lbl);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\usuario\\Documents\\Conversor\\divisas.jpg"));
		lblNewLabel.setBounds(21, 119, 338, 139);
		frmAluraOne.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\usuario\\Documents\\Conversor\\imagen1 - copia.png"));
		lblNewLabel_1.setBounds(375, 11, 57, 55);
		frmAluraOne.getContentPane().add(lblNewLabel_1);
	}
	
	public void Convertir() {
		if(Validar(txt.getText())) {
			Moneda moneda = (Moneda)cmb.getSelectedItem();
			
			switch (moneda) {
			
			case colones_dolar:
				ColonesAMoneda(dolar);
				break;
			case colones_euro:
				ColonesAMoneda(euro);
				break;
			case colones_libra:
				ColonesAMoneda(libra);
				break;
			case dolar_colones:
				MonedaAColones(dolar);
				break;
			default:
			     throw new IllegalArgumentException("Unexpected value: " + moneda);
		}

		}
	}
	
	public void ColonesAMoneda(double moneda) {
		double res = valorInput / moneda;
		lbl.setText(Redondear(res));
	}
	
	public void MonedaAColones(double moneda){
		double res = valorInput * moneda;
		lbl.setText(Redondear(res));
	}
	
	public String Redondear(double valor) {
		DecimalFormat df = new DecimalFormat("0.00");
		df.setRoundingMode(RoundingMode.HALF_UP);
		return df.format(valor);
	}
	
	public boolean Validar(String texto) {
		try {
			double x = Double.parseDouble(texto);
			if(x > 0);
			valorInput = x;
			return true;
		}catch(NumberFormatException e) {
			lbl.setText("Solamente numeros!!");
			return false;
		}
	}
}
